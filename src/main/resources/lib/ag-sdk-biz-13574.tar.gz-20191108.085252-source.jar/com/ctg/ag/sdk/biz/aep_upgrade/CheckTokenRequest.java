package com.ctg.ag.sdk.biz.aep_upgrade;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CheckTokenRequest extends BaseApiRequest {

    public CheckTokenRequest(){
        super(RequestFormat.GET(), "20180910143613"
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("token", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new CheckTokenResponse();
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public CheckTokenRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public CheckTokenRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public CheckTokenRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamToken(){
    	return this.getParam("token");
    }

    public CheckTokenRequest setParamToken(Object value){
    	this.setParam("token", value);
    	return this;
    }
    
    public List<String> getParamsToken(){
    	return this.getParams("token");
    }

    public CheckTokenRequest addParamToken(Object value){
    	this.addParam("token", value);
    	return this;
    }
    
    public CheckTokenRequest addParamsToken(Iterable<?> values){
    	this.addParams("token", values);
    	return this;
    }
    
}