package com.ctg.ag.sdk.biz.aep_rule;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRuleByRuleIdResponse extends BaseApiResponse {
}