package com.ctg.ag.sdk.biz.aep_firmware_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class UpdateFirmwareRequest extends BaseApiRequest {

    public UpdateFirmwareRequest(){
        super(RequestFormat.PUT(), "20190615001705"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new UpdateFirmwareResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public UpdateFirmwareRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public UpdateFirmwareRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public UpdateFirmwareRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public UpdateFirmwareRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public UpdateFirmwareRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public UpdateFirmwareRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}