package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_command_mqtt.GetRemoteInstructionInfoByTaskIdRequest;
import com.ctg.ag.sdk.biz.aep_command_mqtt.GetRemoteInstructionInfoByTaskIdResponse;
import com.ctg.ag.sdk.biz.aep_command_mqtt.AddInstructionMQTTRequest;
import com.ctg.ag.sdk.biz.aep_command_mqtt.AddInstructionMQTTResponse;
import com.ctg.ag.sdk.biz.aep_command_mqtt.QueryInstructionMQTTRequest;
import com.ctg.ag.sdk.biz.aep_command_mqtt.QueryInstructionMQTTResponse;

public final class AepCommandMqttClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandMqttClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandMqttClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_command_mqtt");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_command_mqtt");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_command_mqtt");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_command_mqtt");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepCommandMqttClient build(BuilderParams params) {
				return new AepCommandMqttClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepCommandMqttClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public GetRemoteInstructionInfoByTaskIdResponse getRemoteInstructionInfoByTaskId(GetRemoteInstructionInfoByTaskIdRequest request) throws Exception {
		String apiPath = "/dm/instruction/v1/getRemoteInstructionInfoByTaskId";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetRemoteInstructionInfoByTaskIdResponse> getRemoteInstructionInfoByTaskId(GetRemoteInstructionInfoByTaskIdRequest request, ApiCallBack<GetRemoteInstructionInfoByTaskIdRequest, GetRemoteInstructionInfoByTaskIdResponse> callback) {
		String apiPath = "/dm/instruction/v1/getRemoteInstructionInfoByTaskId";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public AddInstructionMQTTResponse addInstructionMQTT(AddInstructionMQTTRequest request) throws Exception {
		String apiPath = "/dm/instruction/v1/addInstruction";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<AddInstructionMQTTResponse> addInstructionMQTT(AddInstructionMQTTRequest request, ApiCallBack<AddInstructionMQTTRequest, AddInstructionMQTTResponse> callback) {
		String apiPath = "/dm/instruction/v1/addInstruction";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryInstructionMQTTResponse queryInstructionMQTT(QueryInstructionMQTTRequest request) throws Exception {
		String apiPath = "/dm/instruction/v1/queryInstruction";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryInstructionMQTTResponse> queryInstructionMQTT(QueryInstructionMQTTRequest request, ApiCallBack<QueryInstructionMQTTRequest, QueryInstructionMQTTResponse> callback) {
		String apiPath = "/dm/instruction/v1/queryInstruction";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}