package com.ctg.ag.sdk.biz.aep_command_mqtt;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetRemoteInstructionInfoByTaskIdRequest extends BaseApiRequest {

    public GetRemoteInstructionInfoByTaskIdRequest(){
        super(RequestFormat.GET(), "20180725141452"
        , new Meta("taskId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetRemoteInstructionInfoByTaskIdResponse();
    }
    
    public String getParamTaskId(){
    	return this.getParam("taskId");
    }

    public GetRemoteInstructionInfoByTaskIdRequest setParamTaskId(Object value){
    	this.setParam("taskId", value);
    	return this;
    }
    
    public List<String> getParamsTaskId(){
    	return this.getParams("taskId");
    }

    public GetRemoteInstructionInfoByTaskIdRequest addParamTaskId(Object value){
    	this.addParam("taskId", value);
    	return this;
    }
    
    public GetRemoteInstructionInfoByTaskIdRequest addParamsTaskId(Iterable<?> values){
    	this.addParams("taskId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetRemoteInstructionInfoByTaskIdRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetRemoteInstructionInfoByTaskIdRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetRemoteInstructionInfoByTaskIdRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetRemoteInstructionInfoByTaskIdRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetRemoteInstructionInfoByTaskIdRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetRemoteInstructionInfoByTaskIdRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}