package com.ctg.ag.sdk.biz.aep_remote;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreatePromotionResponse extends BaseApiResponse {
}