package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_upgrade.PromotionGetRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.PromotionGetResponse;
import com.ctg.ag.sdk.biz.aep_upgrade.GetDetailsRemoteRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.GetDetailsRemoteResponse;
import com.ctg.ag.sdk.biz.aep_upgrade.DeletePromotionRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.DeletePromotionResponse;
import com.ctg.ag.sdk.biz.aep_upgrade.AddPromotionTaskRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.AddPromotionTaskResponse;
import com.ctg.ag.sdk.biz.aep_upgrade.AddPromotionRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.AddPromotionResponse;
import com.ctg.ag.sdk.biz.aep_upgrade.CheckTokenRequest;
import com.ctg.ag.sdk.biz.aep_upgrade.CheckTokenResponse;

public final class AepUpgradeClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepUpgradeClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepUpgradeClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_upgrade");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_upgrade");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_upgrade");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_upgrade");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepUpgradeClient build(BuilderParams params) {
				return new AepUpgradeClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepUpgradeClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public PromotionGetResponse PromotionGet(PromotionGetRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/getPromotion";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<PromotionGetResponse> PromotionGet(PromotionGetRequest request, ApiCallBack<PromotionGetRequest, PromotionGetResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/getPromotion";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetDetailsRemoteResponse GetDetailsRemote(GetDetailsRemoteRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/details";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetDetailsRemoteResponse> GetDetailsRemote(GetDetailsRemoteRequest request, ApiCallBack<GetDetailsRemoteRequest, GetDetailsRemoteResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/details";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeletePromotionResponse DeletePromotion(DeletePromotionRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/deletepromotion";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeletePromotionResponse> DeletePromotion(DeletePromotionRequest request, ApiCallBack<DeletePromotionRequest, DeletePromotionResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/deletepromotion";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public AddPromotionTaskResponse addPromotionTask(AddPromotionTaskRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/promotion/addPromotionTask";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<AddPromotionTaskResponse> addPromotionTask(AddPromotionTaskRequest request, ApiCallBack<AddPromotionTaskRequest, AddPromotionTaskResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/promotion/addPromotionTask";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public AddPromotionResponse addPromotion(AddPromotionRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/addPromotion";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<AddPromotionResponse> addPromotion(AddPromotionRequest request, ApiCallBack<AddPromotionRequest, AddPromotionResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/addPromotion";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CheckTokenResponse CheckToken(CheckTokenRequest request) throws Exception {
		String apiPath = "/dm/v2/upgrade/remote/promotion/checkToken";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CheckTokenResponse> CheckToken(CheckTokenRequest request, ApiCallBack<CheckTokenRequest, CheckTokenResponse> callback) {
		String apiPath = "/dm/v2/upgrade/remote/promotion/checkToken";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}