package com.ctg.ag.sdk.biz.aep_device_group_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteDeviceGroupRequest extends BaseApiRequest {

    public DeleteDeviceGroupRequest(){
        super(RequestFormat.DELETE(), "20190615001601"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("deviceGroupId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new DeleteDeviceGroupResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public DeleteDeviceGroupRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public DeleteDeviceGroupRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public DeleteDeviceGroupRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamDeviceGroupId(){
    	return this.getParam("deviceGroupId");
    }

    public DeleteDeviceGroupRequest setParamDeviceGroupId(Object value){
    	this.setParam("deviceGroupId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceGroupId(){
    	return this.getParams("deviceGroupId");
    }

    public DeleteDeviceGroupRequest addParamDeviceGroupId(Object value){
    	this.addParam("deviceGroupId", value);
    	return this;
    }
    
    public DeleteDeviceGroupRequest addParamsDeviceGroupId(Iterable<?> values){
    	this.addParams("deviceGroupId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public DeleteDeviceGroupRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public DeleteDeviceGroupRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public DeleteDeviceGroupRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}