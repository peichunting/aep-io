package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_product.ProductGetInfoRequest;
import com.ctg.ag.sdk.biz.aep_product.ProductGetInfoResponse;
import com.ctg.ag.sdk.biz.aep_product.ProductDeleteRequest;
import com.ctg.ag.sdk.biz.aep_product.ProductDeleteResponse;

public final class AepProductClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepProductClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepProductClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_product");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_product");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_product");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_product");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepProductClient build(BuilderParams params) {
				return new AepProductClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepProductClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public ProductGetInfoResponse ProductGetInfo(ProductGetInfoRequest request) throws Exception {
		String apiPath = "/dm/product/v1/product";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ProductGetInfoResponse> ProductGetInfo(ProductGetInfoRequest request, ApiCallBack<ProductGetInfoRequest, ProductGetInfoResponse> callback) {
		String apiPath = "/dm/product/v1/product";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ProductDeleteResponse ProductDelete(ProductDeleteRequest request) throws Exception {
		String apiPath = "/dm/product/v1/deleteInfoByProductId";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ProductDeleteResponse> ProductDelete(ProductDeleteRequest request, ApiCallBack<ProductDeleteRequest, ProductDeleteResponse> callback) {
		String apiPath = "/dm/product/v1/deleteInfoByProductId";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}