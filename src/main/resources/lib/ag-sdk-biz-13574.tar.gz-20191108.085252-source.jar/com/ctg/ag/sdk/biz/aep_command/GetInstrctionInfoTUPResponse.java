package com.ctg.ag.sdk.biz.aep_command;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetInstrctionInfoTUPResponse extends BaseApiResponse {
}