package com.ctg.ag.sdk.biz.aep_order;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateOrderRequest extends BaseApiRequest {

    public CreateOrderRequest(){
        super(RequestFormat.POST(), "20190822094523"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new CreateOrderResponse();
    }
    
}