package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByPublicProductIdRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByPublicProductIdResponse;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByProductIdRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByProductIdResponse;

public final class AepPublicProductManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepPublicProductManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepPublicProductManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_public_product_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepPublicProductManagementClient build(BuilderParams params) {
				return new AepPublicProductManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepPublicProductManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryPublicByPublicProductIdResponse QueryPublicByPublicProductId(QueryPublicByPublicProductIdRequest request) throws Exception {
		String apiPath = "/publicProducts";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryPublicByPublicProductIdResponse> QueryPublicByPublicProductId(QueryPublicByPublicProductIdRequest request, ApiCallBack<QueryPublicByPublicProductIdRequest, QueryPublicByPublicProductIdResponse> callback) {
		String apiPath = "/publicProducts";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryPublicByProductIdResponse QueryPublicByProductId(QueryPublicByProductIdRequest request) throws Exception {
		String apiPath = "/publicProductList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryPublicByProductIdResponse> QueryPublicByProductId(QueryPublicByProductIdRequest request, ApiCallBack<QueryPublicByProductIdRequest, QueryPublicByProductIdResponse> callback) {
		String apiPath = "/publicProductList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}