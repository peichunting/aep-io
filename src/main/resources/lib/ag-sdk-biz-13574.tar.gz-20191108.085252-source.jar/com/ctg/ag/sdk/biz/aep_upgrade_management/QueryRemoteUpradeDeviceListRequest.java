package com.ctg.ag.sdk.biz.aep_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteUpradeDeviceListRequest extends BaseApiRequest {

    public QueryRemoteUpradeDeviceListRequest(){
        super(RequestFormat.GET(), "20190615001451"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("isSelectDevice", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("deviceIdSearch", ParamPosition.QUERY)
        , new Meta("deviceNameSearch", ParamPosition.QUERY)
        , new Meta("imeiSearch", ParamPosition.QUERY)
        , new Meta("deviceNoSearch", ParamPosition.QUERY)
        , new Meta("deviceGroupIdSearch", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryRemoteUpradeDeviceListResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public QueryRemoteUpradeDeviceListRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public QueryRemoteUpradeDeviceListRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryRemoteUpradeDeviceListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryRemoteUpradeDeviceListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamIsSelectDevice(){
    	return this.getParam("isSelectDevice");
    }

    public QueryRemoteUpradeDeviceListRequest setParamIsSelectDevice(Object value){
    	this.setParam("isSelectDevice", value);
    	return this;
    }
    
    public List<String> getParamsIsSelectDevice(){
    	return this.getParams("isSelectDevice");
    }

    public QueryRemoteUpradeDeviceListRequest addParamIsSelectDevice(Object value){
    	this.addParam("isSelectDevice", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsIsSelectDevice(Iterable<?> values){
    	this.addParams("isSelectDevice", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryRemoteUpradeDeviceListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryRemoteUpradeDeviceListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryRemoteUpradeDeviceListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryRemoteUpradeDeviceListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryRemoteUpradeDeviceListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryRemoteUpradeDeviceListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamDeviceIdSearch(){
    	return this.getParam("deviceIdSearch");
    }

    public QueryRemoteUpradeDeviceListRequest setParamDeviceIdSearch(Object value){
    	this.setParam("deviceIdSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceIdSearch(){
    	return this.getParams("deviceIdSearch");
    }

    public QueryRemoteUpradeDeviceListRequest addParamDeviceIdSearch(Object value){
    	this.addParam("deviceIdSearch", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsDeviceIdSearch(Iterable<?> values){
    	this.addParams("deviceIdSearch", values);
    	return this;
    }
    
    public String getParamDeviceNameSearch(){
    	return this.getParam("deviceNameSearch");
    }

    public QueryRemoteUpradeDeviceListRequest setParamDeviceNameSearch(Object value){
    	this.setParam("deviceNameSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceNameSearch(){
    	return this.getParams("deviceNameSearch");
    }

    public QueryRemoteUpradeDeviceListRequest addParamDeviceNameSearch(Object value){
    	this.addParam("deviceNameSearch", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsDeviceNameSearch(Iterable<?> values){
    	this.addParams("deviceNameSearch", values);
    	return this;
    }
    
    public String getParamImeiSearch(){
    	return this.getParam("imeiSearch");
    }

    public QueryRemoteUpradeDeviceListRequest setParamImeiSearch(Object value){
    	this.setParam("imeiSearch", value);
    	return this;
    }
    
    public List<String> getParamsImeiSearch(){
    	return this.getParams("imeiSearch");
    }

    public QueryRemoteUpradeDeviceListRequest addParamImeiSearch(Object value){
    	this.addParam("imeiSearch", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsImeiSearch(Iterable<?> values){
    	this.addParams("imeiSearch", values);
    	return this;
    }
    
    public String getParamDeviceNoSearch(){
    	return this.getParam("deviceNoSearch");
    }

    public QueryRemoteUpradeDeviceListRequest setParamDeviceNoSearch(Object value){
    	this.setParam("deviceNoSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceNoSearch(){
    	return this.getParams("deviceNoSearch");
    }

    public QueryRemoteUpradeDeviceListRequest addParamDeviceNoSearch(Object value){
    	this.addParam("deviceNoSearch", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsDeviceNoSearch(Iterable<?> values){
    	this.addParams("deviceNoSearch", values);
    	return this;
    }
    
    public String getParamDeviceGroupIdSearch(){
    	return this.getParam("deviceGroupIdSearch");
    }

    public QueryRemoteUpradeDeviceListRequest setParamDeviceGroupIdSearch(Object value){
    	this.setParam("deviceGroupIdSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceGroupIdSearch(){
    	return this.getParams("deviceGroupIdSearch");
    }

    public QueryRemoteUpradeDeviceListRequest addParamDeviceGroupIdSearch(Object value){
    	this.addParam("deviceGroupIdSearch", value);
    	return this;
    }
    
    public QueryRemoteUpradeDeviceListRequest addParamsDeviceGroupIdSearch(Iterable<?> values){
    	this.addParams("deviceGroupIdSearch", values);
    	return this;
    }
    
}