package com.ctg.ag.sdk.biz.aep_device_model;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryPropertyListResponse extends BaseApiResponse {
}