package com.ctg.ag.sdk.biz.aep_device_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ModifyDeviceRequest extends BaseApiRequest {

    public ModifyDeviceRequest(){
        super(RequestFormat.POST(), "20180717151423"
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new ModifyDeviceResponse();
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public ModifyDeviceRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public ModifyDeviceRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public ModifyDeviceRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public ModifyDeviceRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public ModifyDeviceRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public ModifyDeviceRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}