package com.ctg.ag.sdk.biz.aep_upgrade;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class PromotionGetRequest extends BaseApiRequest {

    public PromotionGetRequest(){
        super(RequestFormat.GET(), "20180725153619"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("id", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new PromotionGetResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public PromotionGetRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public PromotionGetRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public PromotionGetRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public PromotionGetRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public PromotionGetRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public PromotionGetRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public PromotionGetRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public PromotionGetRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public PromotionGetRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
}