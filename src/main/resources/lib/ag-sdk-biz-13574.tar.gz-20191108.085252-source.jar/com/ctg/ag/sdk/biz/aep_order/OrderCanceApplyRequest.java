package com.ctg.ag.sdk.biz.aep_order;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class OrderCanceApplyRequest extends BaseApiRequest {

    public OrderCanceApplyRequest(){
        super(RequestFormat.POST(), "20190822094516"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new OrderCanceApplyResponse();
    }
    
}