package com.ctg.ag.sdk.biz.aep_command_nb;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetInstructionsListLWM2MResponse extends BaseApiResponse {
}