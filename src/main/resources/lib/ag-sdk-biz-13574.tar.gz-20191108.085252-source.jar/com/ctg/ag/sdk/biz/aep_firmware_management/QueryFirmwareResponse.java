package com.ctg.ag.sdk.biz.aep_firmware_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryFirmwareResponse extends BaseApiResponse {
}