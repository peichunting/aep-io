package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_command_nb.LWM2MCommandRequest;
import com.ctg.ag.sdk.biz.aep_command_nb.LWM2MCommandResponse;
import com.ctg.ag.sdk.biz.aep_command_nb.GetInstrctionInfoLWM2MRequest;
import com.ctg.ag.sdk.biz.aep_command_nb.GetInstrctionInfoLWM2MResponse;
import com.ctg.ag.sdk.biz.aep_command_nb.GetInstructionsListLWM2MRequest;
import com.ctg.ag.sdk.biz.aep_command_nb.GetInstructionsListLWM2MResponse;

public final class AepCommandNbClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandNbClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandNbClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_command_nb");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_command_nb");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_command_nb");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_command_nb");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepCommandNbClient build(BuilderParams params) {
				return new AepCommandNbClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepCommandNbClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public LWM2MCommandResponse LWM2MCommand(LWM2MCommandRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/device/command";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<LWM2MCommandResponse> LWM2MCommand(LWM2MCommandRequest request, ApiCallBack<LWM2MCommandRequest, LWM2MCommandResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/device/command";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetInstrctionInfoLWM2MResponse GetInstrctionInfoLWM2M(GetInstrctionInfoLWM2MRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/remote/instruction/GetInstructionInfo";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetInstrctionInfoLWM2MResponse> GetInstrctionInfoLWM2M(GetInstrctionInfoLWM2MRequest request, ApiCallBack<GetInstrctionInfoLWM2MRequest, GetInstrctionInfoLWM2MResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/remote/instruction/GetInstructionInfo";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetInstructionsListLWM2MResponse GetInstructionsListLWM2M(GetInstructionsListLWM2MRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/remote/instructions";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetInstructionsListLWM2MResponse> GetInstructionsListLWM2M(GetInstructionsListLWM2MRequest request, ApiCallBack<GetInstructionsListLWM2MRequest, GetInstructionsListLWM2MResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/remote/instructions";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}