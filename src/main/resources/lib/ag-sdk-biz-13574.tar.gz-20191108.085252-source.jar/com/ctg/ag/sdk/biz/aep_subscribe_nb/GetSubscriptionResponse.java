package com.ctg.ag.sdk.biz.aep_subscribe_nb;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetSubscriptionResponse extends BaseApiResponse {
}