package com.ctg.ag.sdk.biz.aep_command_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class LWM2MCommandRequest extends BaseApiRequest {

    public LWM2MCommandRequest(){
        super(RequestFormat.POST(), "20180716184119"
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new LWM2MCommandResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public LWM2MCommandRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public LWM2MCommandRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public LWM2MCommandRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}