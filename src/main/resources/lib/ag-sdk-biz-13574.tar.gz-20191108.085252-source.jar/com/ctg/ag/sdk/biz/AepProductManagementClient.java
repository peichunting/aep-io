package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_product_management.QueryProductRequest;
import com.ctg.ag.sdk.biz.aep_product_management.QueryProductResponse;
import com.ctg.ag.sdk.biz.aep_product_management.QueryProductListRequest;
import com.ctg.ag.sdk.biz.aep_product_management.QueryProductListResponse;
import com.ctg.ag.sdk.biz.aep_product_management.DeleteProductRequest;
import com.ctg.ag.sdk.biz.aep_product_management.DeleteProductResponse;
import com.ctg.ag.sdk.biz.aep_product_management.CreateProductRequest;
import com.ctg.ag.sdk.biz.aep_product_management.CreateProductResponse;
import com.ctg.ag.sdk.biz.aep_product_management.UpdateProductRequest;
import com.ctg.ag.sdk.biz.aep_product_management.UpdateProductResponse;

public final class AepProductManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepProductManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepProductManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_product_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_product_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_product_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_product_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepProductManagementClient build(BuilderParams params) {
				return new AepProductManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepProductManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryProductResponse QueryProduct(QueryProductRequest request) throws Exception {
		String apiPath = "/product";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryProductResponse> QueryProduct(QueryProductRequest request, ApiCallBack<QueryProductRequest, QueryProductResponse> callback) {
		String apiPath = "/product";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryProductListResponse QueryProductList(QueryProductListRequest request) throws Exception {
		String apiPath = "/products";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryProductListResponse> QueryProductList(QueryProductListRequest request, ApiCallBack<QueryProductListRequest, QueryProductListResponse> callback) {
		String apiPath = "/products";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteProductResponse DeleteProduct(DeleteProductRequest request) throws Exception {
		String apiPath = "/product";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteProductResponse> DeleteProduct(DeleteProductRequest request, ApiCallBack<DeleteProductRequest, DeleteProductResponse> callback) {
		String apiPath = "/product";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateProductResponse CreateProduct(CreateProductRequest request) throws Exception {
		String apiPath = "/product";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateProductResponse> CreateProduct(CreateProductRequest request, ApiCallBack<CreateProductRequest, CreateProductResponse> callback) {
		String apiPath = "/product";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public UpdateProductResponse UpdateProduct(UpdateProductRequest request) throws Exception {
		String apiPath = "/product";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateProductResponse> UpdateProduct(UpdateProductRequest request, ApiCallBack<UpdateProductRequest, UpdateProductResponse> callback) {
		String apiPath = "/product";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}