package com.ctg.ag.sdk.biz.aep_device;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteInfoByDevicetIdResponse extends BaseApiResponse {
}