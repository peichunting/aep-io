package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_command.TupCommandRequest;
import com.ctg.ag.sdk.biz.aep_command.TupCommandResponse;
import com.ctg.ag.sdk.biz.aep_command.GetInstrctionInfoTUPRequest;
import com.ctg.ag.sdk.biz.aep_command.GetInstrctionInfoTUPResponse;
import com.ctg.ag.sdk.biz.aep_command.GetInstructionsListTUPRequest;
import com.ctg.ag.sdk.biz.aep_command.GetInstructionsListTUPResponse;
import com.ctg.ag.sdk.biz.aep_command.TupCommand_ProfileRequest;
import com.ctg.ag.sdk.biz.aep_command.TupCommand_ProfileResponse;

public final class AepCommandClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepCommandClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_command");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_command");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_command");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_command");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepCommandClient build(BuilderParams params) {
				return new AepCommandClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepCommandClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public TupCommandResponse TupCommand(TupCommandRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/device/tupCommand";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<TupCommandResponse> TupCommand(TupCommandRequest request, ApiCallBack<TupCommandRequest, TupCommandResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/device/tupCommand";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetInstrctionInfoTUPResponse GetInstrctionInfoTUP(GetInstrctionInfoTUPRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/remote/instruction/GetInstructionInfo";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetInstrctionInfoTUPResponse> GetInstrctionInfoTUP(GetInstrctionInfoTUPRequest request, ApiCallBack<GetInstrctionInfoTUPRequest, GetInstrctionInfoTUPResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/remote/instruction/GetInstructionInfo";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetInstructionsListTUPResponse GetInstructionsListTUP(GetInstructionsListTUPRequest request) throws Exception {
		String apiPath = "/dm/v2/lwm2m/remote/instructions";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetInstructionsListTUPResponse> GetInstructionsListTUP(GetInstructionsListTUPRequest request, ApiCallBack<GetInstructionsListTUPRequest, GetInstructionsListTUPResponse> callback) {
		String apiPath = "/dm/v2/lwm2m/remote/instructions";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public TupCommand_ProfileResponse TupCommand_Profile(TupCommand_ProfileRequest request) throws Exception {
		String apiPath = "/dm/v3/tup/command";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<TupCommand_ProfileResponse> TupCommand_Profile(TupCommand_ProfileRequest request, ApiCallBack<TupCommand_ProfileRequest, TupCommand_ProfileResponse> callback) {
		String apiPath = "/dm/v3/tup/command";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}