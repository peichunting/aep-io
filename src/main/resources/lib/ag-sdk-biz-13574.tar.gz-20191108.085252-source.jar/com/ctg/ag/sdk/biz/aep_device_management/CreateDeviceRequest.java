package com.ctg.ag.sdk.biz.aep_device_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateDeviceRequest extends BaseApiRequest {

    public CreateDeviceRequest(){
        super(RequestFormat.POST(), "20181031202117"
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new CreateDeviceResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public CreateDeviceRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public CreateDeviceRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public CreateDeviceRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}