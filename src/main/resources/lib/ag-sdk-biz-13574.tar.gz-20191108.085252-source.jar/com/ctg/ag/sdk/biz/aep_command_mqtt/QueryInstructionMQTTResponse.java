package com.ctg.ag.sdk.biz.aep_command_mqtt;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryInstructionMQTTResponse extends BaseApiResponse {
}