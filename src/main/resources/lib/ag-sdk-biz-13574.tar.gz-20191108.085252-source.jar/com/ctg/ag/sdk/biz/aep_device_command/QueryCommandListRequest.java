package com.ctg.ag.sdk.biz.aep_device_command;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryCommandListRequest extends BaseApiRequest {

    public QueryCommandListRequest(){
        super(RequestFormat.GET(), "20190712225211"
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("status", ParamPosition.QUERY)
        , new Meta("startTime", ParamPosition.QUERY)
        , new Meta("endTime", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("groupCommandId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryCommandListResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryCommandListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryCommandListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryCommandListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryCommandListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryCommandListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryCommandListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public QueryCommandListRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public QueryCommandListRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamStatus(){
    	return this.getParam("status");
    }

    public QueryCommandListRequest setParamStatus(Object value){
    	this.setParam("status", value);
    	return this;
    }
    
    public List<String> getParamsStatus(){
    	return this.getParams("status");
    }

    public QueryCommandListRequest addParamStatus(Object value){
    	this.addParam("status", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsStatus(Iterable<?> values){
    	this.addParams("status", values);
    	return this;
    }
    
    public String getParamStartTime(){
    	return this.getParam("startTime");
    }

    public QueryCommandListRequest setParamStartTime(Object value){
    	this.setParam("startTime", value);
    	return this;
    }
    
    public List<String> getParamsStartTime(){
    	return this.getParams("startTime");
    }

    public QueryCommandListRequest addParamStartTime(Object value){
    	this.addParam("startTime", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsStartTime(Iterable<?> values){
    	this.addParams("startTime", values);
    	return this;
    }
    
    public String getParamEndTime(){
    	return this.getParam("endTime");
    }

    public QueryCommandListRequest setParamEndTime(Object value){
    	this.setParam("endTime", value);
    	return this;
    }
    
    public List<String> getParamsEndTime(){
    	return this.getParams("endTime");
    }

    public QueryCommandListRequest addParamEndTime(Object value){
    	this.addParam("endTime", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsEndTime(Iterable<?> values){
    	this.addParams("endTime", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryCommandListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryCommandListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryCommandListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryCommandListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamGroupCommandId(){
    	return this.getParam("groupCommandId");
    }

    public QueryCommandListRequest setParamGroupCommandId(Object value){
    	this.setParam("groupCommandId", value);
    	return this;
    }
    
    public List<String> getParamsGroupCommandId(){
    	return this.getParams("groupCommandId");
    }

    public QueryCommandListRequest addParamGroupCommandId(Object value){
    	this.addParam("groupCommandId", value);
    	return this;
    }
    
    public QueryCommandListRequest addParamsGroupCommandId(Iterable<?> values){
    	this.addParams("groupCommandId", values);
    	return this;
    }
    
}