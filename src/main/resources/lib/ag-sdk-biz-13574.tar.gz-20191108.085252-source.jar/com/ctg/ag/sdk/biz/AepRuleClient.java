package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_rule.QueryRuleByRuleIdRequest;
import com.ctg.ag.sdk.biz.aep_rule.QueryRuleByRuleIdResponse;
import com.ctg.ag.sdk.biz.aep_rule.SaasUpdateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule.SaasUpdateRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule.SaasDeleteRuleEngineRequest;
import com.ctg.ag.sdk.biz.aep_rule.SaasDeleteRuleEngineResponse;
import com.ctg.ag.sdk.biz.aep_rule.SaasQueryRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule.SaasQueryRuleResponse;
import com.ctg.ag.sdk.biz.aep_rule.SaasCreateRuleRequest;
import com.ctg.ag.sdk.biz.aep_rule.SaasCreateRuleResponse;

public final class AepRuleClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepRuleClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepRuleClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_rule");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_rule");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_rule");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_rule");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepRuleClient build(BuilderParams params) {
				return new AepRuleClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepRuleClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryRuleByRuleIdResponse QueryRuleByRuleId(QueryRuleByRuleIdRequest request) throws Exception {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryRuleByRuleIdResponse> QueryRuleByRuleId(QueryRuleByRuleIdRequest request, ApiCallBack<QueryRuleByRuleIdRequest, QueryRuleByRuleIdResponse> callback) {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasUpdateRuleResponse saasUpdateRule(SaasUpdateRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/updateRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasUpdateRuleResponse> saasUpdateRule(SaasUpdateRuleRequest request, ApiCallBack<SaasUpdateRuleRequest, SaasUpdateRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/updateRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasDeleteRuleEngineResponse saasDeleteRuleEngine(SaasDeleteRuleEngineRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/deleteRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasDeleteRuleEngineResponse> saasDeleteRuleEngine(SaasDeleteRuleEngineRequest request, ApiCallBack<SaasDeleteRuleEngineRequest, SaasDeleteRuleEngineResponse> callback) {
		String apiPath = "/api/v2/rule/sass/deleteRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasQueryRuleResponse saasQueryRule(SaasQueryRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/queryRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasQueryRuleResponse> saasQueryRule(SaasQueryRuleRequest request, ApiCallBack<SaasQueryRuleRequest, SaasQueryRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/queryRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public SaasCreateRuleResponse saasCreateRule(SaasCreateRuleRequest request) throws Exception {
		String apiPath = "/api/v2/rule/sass/createRule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<SaasCreateRuleResponse> saasCreateRule(SaasCreateRuleRequest request, ApiCallBack<SaasCreateRuleRequest, SaasCreateRuleResponse> callback) {
		String apiPath = "/api/v2/rule/sass/createRule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}