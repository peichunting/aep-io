package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_order.CreateOrderRequest;
import com.ctg.ag.sdk.biz.aep_order.CreateOrderResponse;
import com.ctg.ag.sdk.biz.aep_order.CreateRenewOrderRequest;
import com.ctg.ag.sdk.biz.aep_order.CreateRenewOrderResponse;
import com.ctg.ag.sdk.biz.aep_order.RenewPriceRequest;
import com.ctg.ag.sdk.biz.aep_order.RenewPriceResponse;
import com.ctg.ag.sdk.biz.aep_order.OrderCanceApplyRequest;
import com.ctg.ag.sdk.biz.aep_order.OrderCanceApplyResponse;
import com.ctg.ag.sdk.biz.aep_order.PayRequest;
import com.ctg.ag.sdk.biz.aep_order.PayResponse;
import com.ctg.ag.sdk.biz.aep_order.RefundInfoRequest;
import com.ctg.ag.sdk.biz.aep_order.RefundInfoResponse;
import com.ctg.ag.sdk.biz.aep_order.CreateRefundOrderRequest;
import com.ctg.ag.sdk.biz.aep_order.CreateRefundOrderResponse;
import com.ctg.ag.sdk.biz.aep_order.PriceRequest;
import com.ctg.ag.sdk.biz.aep_order.PriceResponse;

public final class AepOrderClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepOrderClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepOrderClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_order");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_order");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_order");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_order");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepOrderClient build(BuilderParams params) {
				return new AepOrderClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepOrderClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public CreateOrderResponse createOrder(CreateOrderRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/create";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateOrderResponse> createOrder(CreateOrderRequest request, ApiCallBack<CreateOrderRequest, CreateOrderResponse> callback) {
		String apiPath = "/aeporder/order/v1/create";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateRenewOrderResponse createRenewOrder(CreateRenewOrderRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/renew";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateRenewOrderResponse> createRenewOrder(CreateRenewOrderRequest request, ApiCallBack<CreateRenewOrderRequest, CreateRenewOrderResponse> callback) {
		String apiPath = "/aeporder/order/v1/renew";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public RenewPriceResponse renewPrice(RenewPriceRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/renewPrice";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<RenewPriceResponse> renewPrice(RenewPriceRequest request, ApiCallBack<RenewPriceRequest, RenewPriceResponse> callback) {
		String apiPath = "/aeporder/order/v1/renewPrice";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public OrderCanceApplyResponse orderCanceApply(OrderCanceApplyRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/orderCanceApply";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<OrderCanceApplyResponse> orderCanceApply(OrderCanceApplyRequest request, ApiCallBack<OrderCanceApplyRequest, OrderCanceApplyResponse> callback) {
		String apiPath = "/aeporder/order/v1/orderCanceApply";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public PayResponse pay(PayRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/pay";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<PayResponse> pay(PayRequest request, ApiCallBack<PayRequest, PayResponse> callback) {
		String apiPath = "/aeporder/order/v1/pay";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public RefundInfoResponse refundInfo(RefundInfoRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/refundInfo";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<RefundInfoResponse> refundInfo(RefundInfoRequest request, ApiCallBack<RefundInfoRequest, RefundInfoResponse> callback) {
		String apiPath = "/aeporder/order/v1/refundInfo";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateRefundOrderResponse createRefundOrder(CreateRefundOrderRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/refund/order";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateRefundOrderResponse> createRefundOrder(CreateRefundOrderRequest request, ApiCallBack<CreateRefundOrderRequest, CreateRefundOrderResponse> callback) {
		String apiPath = "/aeporder/order/v1/refund/order";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public PriceResponse price(PriceRequest request) throws Exception {
		String apiPath = "/aeporder/order/v1/price";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<PriceResponse> price(PriceRequest request, ApiCallBack<PriceRequest, PriceResponse> callback) {
		String apiPath = "/aeporder/order/v1/price";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}