package com.ctg.ag.sdk.biz.aep_product_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateProductRequest extends BaseApiRequest {

    public CreateProductRequest(){
        super(RequestFormat.POST(), "20191018204154"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new CreateProductResponse();
    }
    
}