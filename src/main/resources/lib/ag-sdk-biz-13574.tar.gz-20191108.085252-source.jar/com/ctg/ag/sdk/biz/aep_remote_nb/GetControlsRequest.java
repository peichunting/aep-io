package com.ctg.ag.sdk.biz.aep_remote_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetControlsRequest extends BaseApiRequest {

    public GetControlsRequest(){
        super(RequestFormat.GET(), "20180717094452"
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("imei", ParamPosition.QUERY)
        , new Meta("taskType", ParamPosition.QUERY)
        , new Meta("taskStatus", ParamPosition.QUERY)
        , new Meta("stTime", ParamPosition.QUERY)
        , new Meta("edTime", ParamPosition.QUERY)
        , new Meta("abilityId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetControlsResponse();
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public GetControlsRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public GetControlsRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public GetControlsRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetControlsRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetControlsRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetControlsRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetControlsRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetControlsRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetControlsRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetControlsRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetControlsRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetControlsRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetControlsRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetControlsRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetControlsRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamImei(){
    	return this.getParam("imei");
    }

    public GetControlsRequest setParamImei(Object value){
    	this.setParam("imei", value);
    	return this;
    }
    
    public List<String> getParamsImei(){
    	return this.getParams("imei");
    }

    public GetControlsRequest addParamImei(Object value){
    	this.addParam("imei", value);
    	return this;
    }
    
    public GetControlsRequest addParamsImei(Iterable<?> values){
    	this.addParams("imei", values);
    	return this;
    }
    
    public String getParamTaskType(){
    	return this.getParam("taskType");
    }

    public GetControlsRequest setParamTaskType(Object value){
    	this.setParam("taskType", value);
    	return this;
    }
    
    public List<String> getParamsTaskType(){
    	return this.getParams("taskType");
    }

    public GetControlsRequest addParamTaskType(Object value){
    	this.addParam("taskType", value);
    	return this;
    }
    
    public GetControlsRequest addParamsTaskType(Iterable<?> values){
    	this.addParams("taskType", values);
    	return this;
    }
    
    public String getParamTaskStatus(){
    	return this.getParam("taskStatus");
    }

    public GetControlsRequest setParamTaskStatus(Object value){
    	this.setParam("taskStatus", value);
    	return this;
    }
    
    public List<String> getParamsTaskStatus(){
    	return this.getParams("taskStatus");
    }

    public GetControlsRequest addParamTaskStatus(Object value){
    	this.addParam("taskStatus", value);
    	return this;
    }
    
    public GetControlsRequest addParamsTaskStatus(Iterable<?> values){
    	this.addParams("taskStatus", values);
    	return this;
    }
    
    public String getParamStTime(){
    	return this.getParam("stTime");
    }

    public GetControlsRequest setParamStTime(Object value){
    	this.setParam("stTime", value);
    	return this;
    }
    
    public List<String> getParamsStTime(){
    	return this.getParams("stTime");
    }

    public GetControlsRequest addParamStTime(Object value){
    	this.addParam("stTime", value);
    	return this;
    }
    
    public GetControlsRequest addParamsStTime(Iterable<?> values){
    	this.addParams("stTime", values);
    	return this;
    }
    
    public String getParamEdTime(){
    	return this.getParam("edTime");
    }

    public GetControlsRequest setParamEdTime(Object value){
    	this.setParam("edTime", value);
    	return this;
    }
    
    public List<String> getParamsEdTime(){
    	return this.getParams("edTime");
    }

    public GetControlsRequest addParamEdTime(Object value){
    	this.addParam("edTime", value);
    	return this;
    }
    
    public GetControlsRequest addParamsEdTime(Iterable<?> values){
    	this.addParams("edTime", values);
    	return this;
    }
    
    public String getParamAbilityId(){
    	return this.getParam("abilityId");
    }

    public GetControlsRequest setParamAbilityId(Object value){
    	this.setParam("abilityId", value);
    	return this;
    }
    
    public List<String> getParamsAbilityId(){
    	return this.getParams("abilityId");
    }

    public GetControlsRequest addParamAbilityId(Object value){
    	this.addParam("abilityId", value);
    	return this;
    }
    
    public GetControlsRequest addParamsAbilityId(Iterable<?> values){
    	this.addParams("abilityId", values);
    	return this;
    }
    
}