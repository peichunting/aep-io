package com.ctg.ag.sdk.biz.aep_product;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ProductGetInfoRequest extends BaseApiRequest {

    public ProductGetInfoRequest(){
        super(RequestFormat.GET(), "20180717135002"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new ProductGetInfoResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public ProductGetInfoRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public ProductGetInfoRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public ProductGetInfoRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public ProductGetInfoRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public ProductGetInfoRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public ProductGetInfoRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}