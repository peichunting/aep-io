package com.ctg.ag.sdk.biz.aep_device;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class AddDeviceInfoRequest extends BaseApiRequest {

    public AddDeviceInfoRequest(){
        super(RequestFormat.POST(), "20180801111438"
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new AddDeviceInfoResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public AddDeviceInfoRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public AddDeviceInfoRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public AddDeviceInfoRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}