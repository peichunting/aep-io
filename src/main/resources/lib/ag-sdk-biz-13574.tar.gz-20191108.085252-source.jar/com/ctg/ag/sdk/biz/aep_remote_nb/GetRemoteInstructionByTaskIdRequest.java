package com.ctg.ag.sdk.biz.aep_remote_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetRemoteInstructionByTaskIdRequest extends BaseApiRequest {

    public GetRemoteInstructionByTaskIdRequest(){
        super(RequestFormat.GET(), "20180717095713"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("taskId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetRemoteInstructionByTaskIdResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetRemoteInstructionByTaskIdRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetRemoteInstructionByTaskIdRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetRemoteInstructionByTaskIdRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamTaskId(){
    	return this.getParam("taskId");
    }

    public GetRemoteInstructionByTaskIdRequest setParamTaskId(Object value){
    	this.setParam("taskId", value);
    	return this;
    }
    
    public List<String> getParamsTaskId(){
    	return this.getParams("taskId");
    }

    public GetRemoteInstructionByTaskIdRequest addParamTaskId(Object value){
    	this.addParam("taskId", value);
    	return this;
    }
    
    public GetRemoteInstructionByTaskIdRequest addParamsTaskId(Iterable<?> values){
    	this.addParams("taskId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetRemoteInstructionByTaskIdRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetRemoteInstructionByTaskIdRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetRemoteInstructionByTaskIdRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}