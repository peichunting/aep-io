package com.ctg.ag.sdk.biz.aep_upgrade;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class PromotionGetResponse extends BaseApiResponse {
}