package com.ctg.ag.sdk.biz.usr;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class SdkDownloadRequest extends BaseApiRequest {

    public SdkDownloadRequest(){
        super(RequestFormat.GET(), "20180000000000"
        , new Meta("sdk_type", ParamPosition.QUERY)
        , new Meta("file_name", ParamPosition.QUERY)
        , new Meta("application_id", ParamPosition.QUERY)
        , new Meta("api_version", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new SdkDownloadResponse();
    }
    
    public String getParamSdk_type(){
    	return this.getParam("sdk_type");
    }

    public SdkDownloadRequest setParamSdk_type(Object value){
    	this.setParam("sdk_type", value);
    	return this;
    }
    
    public List<String> getParamsSdk_type(){
    	return this.getParams("sdk_type");
    }

    public SdkDownloadRequest addParamSdk_type(Object value){
    	this.addParam("sdk_type", value);
    	return this;
    }
    
    public SdkDownloadRequest addParamsSdk_type(Iterable<?> values){
    	this.addParams("sdk_type", values);
    	return this;
    }
    
    public String getParamFile_name(){
    	return this.getParam("file_name");
    }

    public SdkDownloadRequest setParamFile_name(Object value){
    	this.setParam("file_name", value);
    	return this;
    }
    
    public List<String> getParamsFile_name(){
    	return this.getParams("file_name");
    }

    public SdkDownloadRequest addParamFile_name(Object value){
    	this.addParam("file_name", value);
    	return this;
    }
    
    public SdkDownloadRequest addParamsFile_name(Iterable<?> values){
    	this.addParams("file_name", values);
    	return this;
    }
    
    public String getParamApplication_id(){
    	return this.getParam("application_id");
    }

    public SdkDownloadRequest setParamApplication_id(Object value){
    	this.setParam("application_id", value);
    	return this;
    }
    
    public List<String> getParamsApplication_id(){
    	return this.getParams("application_id");
    }

    public SdkDownloadRequest addParamApplication_id(Object value){
    	this.addParam("application_id", value);
    	return this;
    }
    
    public SdkDownloadRequest addParamsApplication_id(Iterable<?> values){
    	this.addParams("application_id", values);
    	return this;
    }
    
    public String getParamApi_version(){
    	return this.getParam("api_version");
    }

    public SdkDownloadRequest setParamApi_version(Object value){
    	this.setParam("api_version", value);
    	return this;
    }
    
    public List<String> getParamsApi_version(){
    	return this.getParams("api_version");
    }

    public SdkDownloadRequest addParamApi_version(Object value){
    	this.addParam("api_version", value);
    	return this;
    }
    
    public SdkDownloadRequest addParamsApi_version(Iterable<?> values){
    	this.addParams("api_version", values);
    	return this;
    }
    
}