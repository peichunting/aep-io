package com.ctg.ag.sdk.biz.aep_upgrade;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetDetailsRemoteRequest extends BaseApiRequest {

    public GetDetailsRemoteRequest(){
        super(RequestFormat.GET(), "20180717114030"
        , new Meta("jobId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("taskStatus", ParamPosition.QUERY)
        , new Meta("selectValue", ParamPosition.QUERY)
        , new Meta("promoteType", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetDetailsRemoteResponse();
    }
    
    public String getParamJobId(){
    	return this.getParam("jobId");
    }

    public GetDetailsRemoteRequest setParamJobId(Object value){
    	this.setParam("jobId", value);
    	return this;
    }
    
    public List<String> getParamsJobId(){
    	return this.getParams("jobId");
    }

    public GetDetailsRemoteRequest addParamJobId(Object value){
    	this.addParam("jobId", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsJobId(Iterable<?> values){
    	this.addParams("jobId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetDetailsRemoteRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetDetailsRemoteRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamTaskStatus(){
    	return this.getParam("taskStatus");
    }

    public GetDetailsRemoteRequest setParamTaskStatus(Object value){
    	this.setParam("taskStatus", value);
    	return this;
    }
    
    public List<String> getParamsTaskStatus(){
    	return this.getParams("taskStatus");
    }

    public GetDetailsRemoteRequest addParamTaskStatus(Object value){
    	this.addParam("taskStatus", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsTaskStatus(Iterable<?> values){
    	this.addParams("taskStatus", values);
    	return this;
    }
    
    public String getParamSelectValue(){
    	return this.getParam("selectValue");
    }

    public GetDetailsRemoteRequest setParamSelectValue(Object value){
    	this.setParam("selectValue", value);
    	return this;
    }
    
    public List<String> getParamsSelectValue(){
    	return this.getParams("selectValue");
    }

    public GetDetailsRemoteRequest addParamSelectValue(Object value){
    	this.addParam("selectValue", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsSelectValue(Iterable<?> values){
    	this.addParams("selectValue", values);
    	return this;
    }
    
    public String getParamPromoteType(){
    	return this.getParam("promoteType");
    }

    public GetDetailsRemoteRequest setParamPromoteType(Object value){
    	this.setParam("promoteType", value);
    	return this;
    }
    
    public List<String> getParamsPromoteType(){
    	return this.getParams("promoteType");
    }

    public GetDetailsRemoteRequest addParamPromoteType(Object value){
    	this.addParam("promoteType", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsPromoteType(Iterable<?> values){
    	this.addParams("promoteType", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetDetailsRemoteRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetDetailsRemoteRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetDetailsRemoteRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetDetailsRemoteRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetDetailsRemoteRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetDetailsRemoteRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetDetailsRemoteRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}