package com.ctg.ag.sdk.biz.aep_order;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class PriceResponse extends BaseApiResponse {
}