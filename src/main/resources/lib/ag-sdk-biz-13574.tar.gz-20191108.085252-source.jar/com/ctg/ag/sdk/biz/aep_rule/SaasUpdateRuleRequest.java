package com.ctg.ag.sdk.biz.aep_rule;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class SaasUpdateRuleRequest extends BaseApiRequest {

    public SaasUpdateRuleRequest(){
        super(RequestFormat.POST(), "20190810004339"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new SaasUpdateRuleResponse();
    }
    
}