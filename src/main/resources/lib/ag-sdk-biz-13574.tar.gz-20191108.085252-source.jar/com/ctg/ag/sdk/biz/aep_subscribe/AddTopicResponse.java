package com.ctg.ag.sdk.biz.aep_subscribe;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class AddTopicResponse extends BaseApiResponse {
}