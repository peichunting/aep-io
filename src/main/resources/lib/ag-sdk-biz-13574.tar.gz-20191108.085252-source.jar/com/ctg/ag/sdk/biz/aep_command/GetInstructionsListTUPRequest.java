package com.ctg.ag.sdk.biz.aep_command;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetInstructionsListTUPRequest extends BaseApiRequest {

    public GetInstructionsListTUPRequest(){
        super(RequestFormat.GET(), "20180824140017"
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("imei", ParamPosition.QUERY)
        , new Meta("taskType", ParamPosition.QUERY)
        , new Meta("taskStatus", ParamPosition.QUERY)
        , new Meta("stTime", ParamPosition.QUERY)
        , new Meta("edTime", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetInstructionsListTUPResponse();
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public GetInstructionsListTUPRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public GetInstructionsListTUPRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetInstructionsListTUPRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetInstructionsListTUPRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetInstructionsListTUPRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetInstructionsListTUPRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetInstructionsListTUPRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetInstructionsListTUPRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetInstructionsListTUPRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetInstructionsListTUPRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamImei(){
    	return this.getParam("imei");
    }

    public GetInstructionsListTUPRequest setParamImei(Object value){
    	this.setParam("imei", value);
    	return this;
    }
    
    public List<String> getParamsImei(){
    	return this.getParams("imei");
    }

    public GetInstructionsListTUPRequest addParamImei(Object value){
    	this.addParam("imei", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsImei(Iterable<?> values){
    	this.addParams("imei", values);
    	return this;
    }
    
    public String getParamTaskType(){
    	return this.getParam("taskType");
    }

    public GetInstructionsListTUPRequest setParamTaskType(Object value){
    	this.setParam("taskType", value);
    	return this;
    }
    
    public List<String> getParamsTaskType(){
    	return this.getParams("taskType");
    }

    public GetInstructionsListTUPRequest addParamTaskType(Object value){
    	this.addParam("taskType", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsTaskType(Iterable<?> values){
    	this.addParams("taskType", values);
    	return this;
    }
    
    public String getParamTaskStatus(){
    	return this.getParam("taskStatus");
    }

    public GetInstructionsListTUPRequest setParamTaskStatus(Object value){
    	this.setParam("taskStatus", value);
    	return this;
    }
    
    public List<String> getParamsTaskStatus(){
    	return this.getParams("taskStatus");
    }

    public GetInstructionsListTUPRequest addParamTaskStatus(Object value){
    	this.addParam("taskStatus", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsTaskStatus(Iterable<?> values){
    	this.addParams("taskStatus", values);
    	return this;
    }
    
    public String getParamStTime(){
    	return this.getParam("stTime");
    }

    public GetInstructionsListTUPRequest setParamStTime(Object value){
    	this.setParam("stTime", value);
    	return this;
    }
    
    public List<String> getParamsStTime(){
    	return this.getParams("stTime");
    }

    public GetInstructionsListTUPRequest addParamStTime(Object value){
    	this.addParam("stTime", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsStTime(Iterable<?> values){
    	this.addParams("stTime", values);
    	return this;
    }
    
    public String getParamEdTime(){
    	return this.getParam("edTime");
    }

    public GetInstructionsListTUPRequest setParamEdTime(Object value){
    	this.setParam("edTime", value);
    	return this;
    }
    
    public List<String> getParamsEdTime(){
    	return this.getParams("edTime");
    }

    public GetInstructionsListTUPRequest addParamEdTime(Object value){
    	this.addParam("edTime", value);
    	return this;
    }
    
    public GetInstructionsListTUPRequest addParamsEdTime(Iterable<?> values){
    	this.addParams("edTime", values);
    	return this;
    }
    
}