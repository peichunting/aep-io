package com.ctg.ag.sdk.biz.aep_device_nb;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryDeviceResponse extends BaseApiResponse {
}