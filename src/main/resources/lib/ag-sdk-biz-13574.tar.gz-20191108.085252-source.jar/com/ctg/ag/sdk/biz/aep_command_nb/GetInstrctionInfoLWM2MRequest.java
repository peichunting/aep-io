package com.ctg.ag.sdk.biz.aep_command_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetInstrctionInfoLWM2MRequest extends BaseApiRequest {

    public GetInstrctionInfoLWM2MRequest(){
        super(RequestFormat.GET(), "20180716184229"
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("taskId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetInstrctionInfoLWM2MResponse();
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetInstrctionInfoLWM2MRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetInstrctionInfoLWM2MRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetInstrctionInfoLWM2MRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamTaskId(){
    	return this.getParam("taskId");
    }

    public GetInstrctionInfoLWM2MRequest setParamTaskId(Object value){
    	this.setParam("taskId", value);
    	return this;
    }
    
    public List<String> getParamsTaskId(){
    	return this.getParams("taskId");
    }

    public GetInstrctionInfoLWM2MRequest addParamTaskId(Object value){
    	this.addParam("taskId", value);
    	return this;
    }
    
    public GetInstrctionInfoLWM2MRequest addParamsTaskId(Iterable<?> values){
    	this.addParams("taskId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetInstrctionInfoLWM2MRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetInstrctionInfoLWM2MRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetInstrctionInfoLWM2MRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}