package com.ctg.ag.sdk.biz.aep_command_nb;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetInstructionsListLWM2MRequest extends BaseApiRequest {

    public GetInstructionsListLWM2MRequest(){
        super(RequestFormat.GET(), "20180824141500"
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("imei", ParamPosition.QUERY)
        , new Meta("taskType", ParamPosition.QUERY)
        , new Meta("taskStatus", ParamPosition.QUERY)
        , new Meta("stTime", ParamPosition.QUERY)
        , new Meta("edTime", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetInstructionsListLWM2MResponse();
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public GetInstructionsListLWM2MRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public GetInstructionsListLWM2MRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetInstructionsListLWM2MRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetInstructionsListLWM2MRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetInstructionsListLWM2MRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetInstructionsListLWM2MRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetInstructionsListLWM2MRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetInstructionsListLWM2MRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetInstructionsListLWM2MRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetInstructionsListLWM2MRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamImei(){
    	return this.getParam("imei");
    }

    public GetInstructionsListLWM2MRequest setParamImei(Object value){
    	this.setParam("imei", value);
    	return this;
    }
    
    public List<String> getParamsImei(){
    	return this.getParams("imei");
    }

    public GetInstructionsListLWM2MRequest addParamImei(Object value){
    	this.addParam("imei", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsImei(Iterable<?> values){
    	this.addParams("imei", values);
    	return this;
    }
    
    public String getParamTaskType(){
    	return this.getParam("taskType");
    }

    public GetInstructionsListLWM2MRequest setParamTaskType(Object value){
    	this.setParam("taskType", value);
    	return this;
    }
    
    public List<String> getParamsTaskType(){
    	return this.getParams("taskType");
    }

    public GetInstructionsListLWM2MRequest addParamTaskType(Object value){
    	this.addParam("taskType", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsTaskType(Iterable<?> values){
    	this.addParams("taskType", values);
    	return this;
    }
    
    public String getParamTaskStatus(){
    	return this.getParam("taskStatus");
    }

    public GetInstructionsListLWM2MRequest setParamTaskStatus(Object value){
    	this.setParam("taskStatus", value);
    	return this;
    }
    
    public List<String> getParamsTaskStatus(){
    	return this.getParams("taskStatus");
    }

    public GetInstructionsListLWM2MRequest addParamTaskStatus(Object value){
    	this.addParam("taskStatus", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsTaskStatus(Iterable<?> values){
    	this.addParams("taskStatus", values);
    	return this;
    }
    
    public String getParamStTime(){
    	return this.getParam("stTime");
    }

    public GetInstructionsListLWM2MRequest setParamStTime(Object value){
    	this.setParam("stTime", value);
    	return this;
    }
    
    public List<String> getParamsStTime(){
    	return this.getParams("stTime");
    }

    public GetInstructionsListLWM2MRequest addParamStTime(Object value){
    	this.addParam("stTime", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsStTime(Iterable<?> values){
    	this.addParams("stTime", values);
    	return this;
    }
    
    public String getParamEdTime(){
    	return this.getParam("edTime");
    }

    public GetInstructionsListLWM2MRequest setParamEdTime(Object value){
    	this.setParam("edTime", value);
    	return this;
    }
    
    public List<String> getParamsEdTime(){
    	return this.getParams("edTime");
    }

    public GetInstructionsListLWM2MRequest addParamEdTime(Object value){
    	this.addParam("edTime", value);
    	return this;
    }
    
    public GetInstructionsListLWM2MRequest addParamsEdTime(Iterable<?> values){
    	this.addParams("edTime", values);
    	return this;
    }
    
}